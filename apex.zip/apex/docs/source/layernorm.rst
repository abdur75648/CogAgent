.. role:: hidden
    :class: hidden-section

apex.normalization.fused_layer_norm
===================================

.. automodule:: apex.normalization
.. currentmodule:: apex.normalization

.. FusedAdam
   ----------

.. autoclass:: FusedLayerNorm
    :members:

.. autoclass:: FusedRMSNorm
    :members:
